package com.guigu.utils;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidDataSourceFactory;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

public class JdbcUtils {
    /*使用Druid数据库连接池回去连接*/
    //创建一个Druid数据库连接池
    private static DruidDataSource dataSource;

    // 创建一个ThreadLocal，用来关联连接
    private static ThreadLocal<Connection> conns = new ThreadLocal<Connection>();

    static {// 通过静态代码块，将声明的连接池，实例化
        try {
            Properties props = new Properties();
            //ClassLoader获取系统类加载器，通过传入配置文件信息，得到字符输入流----------读取jdbc.properties属性配置文件
            InputStream is = JdbcUtils.class.getClassLoader().getResourceAsStream("jdbc.properties");
            props.load(is);//加载有配置文件的输入流到配置文件对象----------从流中加载数据
            // DataSource Source = new DruidDataSource(); 调用setXXX(),就写死了4个信息
            // 通过Druid数据连接池父类工厂，根据配置文件对象，创建数据连接池
            dataSource = (DruidDataSource) DruidDataSourceFactory.createDataSource(props);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /**
     * 获取数据库连接池中的连接
     * @return
     */
    public static Connection getConnection(){
        // 从ThreadLocal中获取连接
        Connection conn = conns.get();
        // 第一次ThreadLocal中没有连接，就从Druid连接池获取
        if(conn == null){
            try {
                conn=dataSource.getConnection();  // 连接池中获取
                conns.set(conn); // 保存到ThreadLocal对象中，供后面的jdbc操作
                conn.setAutoCommit(false); // 设置手动管理事务
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return conn;
        /*DruidPooledConnection conn = null;
        try {
            conn = dataSource.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }*/
    }

    /**
     * 提交事务，并释放连接
     */
    public static void commitAndClose(){
        Connection conn = conns.get();
        if(conn != null){ // 如果不等于null，说明 之前使用过连接，---那么操作过数据库
            try {
                conn.commit();  // 提交 事务
            } catch (SQLException e) {
                e.printStackTrace();
            }finally {
                try {
                    conn.close(); // 关闭连接，资源资源
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        } // 一定要执行remove操作，否则就会出错。（因为Tomcat服务器底层使用了线程池技术）
        conns.remove();
    }

    /**
     * 回滚事务，并释放连接---返回连接池
     */
    public static void rollbackAndClose(){
        Connection connection = conns.get();
        if (connection != null) { // 如果不等于null，说明 之前使用过连接，操作过数据库
            try {
                connection.rollback();//回滚事务
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                try {
                    connection.close(); // 关闭连接，资源资源
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        // 一定要执行remove操作，否则就会出错。（因为Tomcat服务器底层使用了线程池技术）
        conns.remove();
    }

    /**
     * 关闭连接，并释放连接---返回连接池
     * @param conn
     */
    /*public static void close(Connection conn){
        if(conn!=null){
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }*/
}
