package com.guigu.utils;

import org.apache.commons.beanutils.BeanUtils;

import java.util.Map;

public class WebUtils {
    /**
     * 参数注入
     * @param value Map集合
     * @param bean
     * @param <T>
     * @return 返回一个带有参数的Bean对象
     */
    public static <T> T copyParamToBean(Map value, T bean) {
        System.out.println("注入之前" + bean);
        try {
            BeanUtils.populate(bean, value);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("注入之后" + bean);
        return bean;
    }

    /**
     * 将字符串转换成int类型的数据
     * @param strInt
     * @param defaultValue
     * @return
     */
    public static int parseInt(String strInt, int defaultValue) {
        try {
            if(strInt!=null){
                return Integer.parseInt(strInt); //方法注意参数传入，不能传入默认值
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return defaultValue; // 如果字符本身内容不是整型，则结果返回默认值
    }
}


