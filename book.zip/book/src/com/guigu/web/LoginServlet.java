package com.guigu.web;

import com.guigu.pojo.User;
import com.guigu.service.UserService;
import com.guigu.service.impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class LoginServlet extends HttpServlet {
    UserService userService = new UserServiceImpl();
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//         1. 获取请求的参数
        String username = req.getParameter("username");
        String password = req.getParameter("password");
//         2. 调用XxxService.xxx()处理业务
        User loginUser = userService.login(new User(null, username, password, null)); // ctrl+Q 查看的是接口方法备注
//         userService.Login登录
//         3. 根据Login()方法返回结果判断登录是否成功
        if(loginUser==null){
//            失败
//                跳回登录页面
            req.setAttribute("msg","用户名或密码错误！");
            req.setAttribute("username",username);
            req.getRequestDispatcher("/pages/user/login.jsp").forward(req,resp);
        }else {
//            成功
//                跳到成功页面login_success.html
            System.out.println("登陆成功！");
            req.getRequestDispatcher("/pages/user/login_success.jsp").forward(req,resp); // 不能忘记forward
        }
    }
}
