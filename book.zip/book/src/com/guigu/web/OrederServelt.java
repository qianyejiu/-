package com.guigu.web;

import com.guigu.pojo.Cart;
import com.guigu.pojo.OrderItem;
import com.guigu.pojo.User;
import com.guigu.service.OrderService;
import com.guigu.service.impl.OrderServiceImpl;
import com.guigu.utils.JdbcUtils;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/*思路：web需要使用service的createorder(cart,userId)，就需要cart对象、userid
* 获取cart对象--------从session域中获取
* 获取userId---------从session域中获取User对象----再获取id
* 获取的订单号orderId存入request域中*/
public class OrederServelt extends BaseServlet {
    private OrderService orderService = new OrderServiceImpl();
    protected void createOrder(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 获取Cart对象
        Cart cart = (Cart) req.getSession().getAttribute("cart");//CartServlet---addItem中
        // 获取userId
        User loginUser = (User) req.getSession().getAttribute("user");//UserServlet---login中
        // session用户为空，说明没有登录，返回登录页面
        if (loginUser == null) {
            req.getRequestDispatcher("/pages/user/login.jsp").forward(req,resp);
            return;
        }
        // 登录后才能获取用户ID---生成订单
        Integer userId = loginUser.getId();
        // 调用orderService.createOrder(cart,userId); 生成订单
        String orderId = orderId = orderService.createOrder(cart, userId); // 一系列jdbc操作

        // 获取的订单号orderId存入session域中
        req.getSession().setAttribute("orderId",orderId);
        // 重定向到结算页面---防止表单重复提交
        resp.sendRedirect(req.getContextPath()+"/pages/cart/checkout.jsp");
    }
}
