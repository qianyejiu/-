package com.guigu.web;

import com.google.gson.Gson;
import com.guigu.pojo.User;

import com.guigu.service.UserService;
import com.guigu.service.impl.UserServiceImpl;
import com.guigu.utils.WebUtils;
import com.mysql.cj.xdevapi.Session;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;

import static com.google.code.kaptcha.Constants.KAPTCHA_SESSION_KEY;

/*
* 通过获取指向当前Servlet程序的post请求中的表单隐藏域的值，来判断执行登录还是注册操作
* */

public class UserServlet extends BaseServlet {
    // 创建用户业务类对象
    UserService userService = new UserServiceImpl();

    protected void ajaxExistsUsername(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 获取用户名
        String username = req.getParameter("username");

        boolean existsUsername = userService.existsUsername(username);
        // 返回结果封装成map对象
        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("existsUsername",existsUsername);
        // 变成json字符串
        Gson gson = new Gson();
        String json = gson.toJson(resultMap);
        resp.getWriter().write(json); // resp 回写 字符串
    }
    /**
     * 处理注销的方法
     *
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    protected void logout(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//        1、销毁Session中用户登录的信息（或者销毁Session）
        req.getSession().invalidate();
//        2、重定向到首页（或登录页面）。
        resp.sendRedirect(req.getContextPath());
    }

    /**
     * 处理登录的方法
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    protected void login(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 1. 获取请求的参数
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        // 2. 调用XxxService.xxx()处理业务
        User loginUser = userService.login(new User(null, username, password, null)); // ctrl+Q 查看的是接口方法备注
        // 3. 根据Login()方法返回结果判断登录是否成功
        if(loginUser==null){
            // 失败，把错误信息，和回显的表单项信息，保存到Request域中 -----  提供给返请求转发回页面使用
            req.setAttribute("msg","用户名或密码错误！");
            req.setAttribute("username",username);
            // 跳回登录页面
            req.getRequestDispatcher("/pages/user/login.jsp").forward(req,resp);
        }else {
            // 成功，跳到成功页面login_success.html
            // 保存用户登录的信息到Session域中      --------    供后面的页面操作使用（生成订单---得到用户id---从session域中得到）(权限检查获取用户)
            req.getSession().setAttribute("user", loginUser);
            req.getRequestDispatcher("/pages/user/login_success.jsp").forward(req,resp); // 不能忘记forward
        }
    }
    /**
     * 处理注册的方法
     *
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    protected void regist(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        // 获取Session中的验证码
        String token = (String) req.getSession().getAttribute(KAPTCHA_SESSION_KEY);
        // 删除 Session中的验证码
        req.getSession().removeAttribute(KAPTCHA_SESSION_KEY);

        // 1. 获取请求的参数
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String repwd = req.getParameter("repwd");
        String email = req.getParameter("email");
        String code = req.getParameter("code");

        // 参数注入
        User user = WebUtils.copyParamToBean(req.getParameterMap(),new User());

        // 设置回显参数
        req.setAttribute("password",password);
        req.setAttribute("repwd",repwd);
        req.setAttribute("username",username);
        req.setAttribute("email",email);
        // 2. 检查验证码是否正确 ---  写死，要求验证码为：6m6mp
        if(token!=null && token.equalsIgnoreCase(code)){
            // 正确
            // 3。检查 用户名是否可用
            if(userService.existsUsername(username)){
                // 把错误信息回显，保存到Request域中
                req.setAttribute("msg","用户名已存在");

                // 用户名不可用，跳回注册页面
                req.getRequestDispatcher("/pages/user/regist.jsp").forward(req,resp);
            }else {
                // 用户名可用，调用Servlet保存到数据库 ，获取的参数封装到User对象
                userService.registUser(new User(null,username,password,email));
                // 跳到注册成功界面 regist_success.jsp
                req.getRequestDispatcher("/pages/user/regist_success.jsp").forward(req,resp);
            }
        }else {
            // 不正确，跳回注册页面
            req.setAttribute("img","验证码错误");
            req.getRequestDispatcher("/pages/user/regist.jsp").forward(req,resp);
        }
    }
}
