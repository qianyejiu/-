package com.guigu.test;

import com.guigu.dao.impl.OrderDaoImpl;
import com.guigu.dao.impl.OrderItemDaoImpl;
import com.guigu.pojo.Cart;
import com.guigu.pojo.CartItem;
import com.guigu.service.OrderService;
import com.guigu.service.impl.OrderServiceImpl;
import org.junit.Test;

import java.math.BigDecimal;


public class OrderServiceTest {

    @Test
    public void createOrder() {
        // 创建需要传入的购物车
        Cart cart = new Cart();
        // 向购物车中添加商品项
        cart.addItem(new CartItem(1, "java从入门到精通", 1, new BigDecimal(1000),new BigDecimal(1000)));
        cart.addItem(new CartItem(2, "数据结构与算法", 1, new BigDecimal(100),new BigDecimal(100)));
        // 创建订单业务对象
        OrderService orderService = new OrderServiceImpl();
        // 业务调用---创建订单---传入需要的购物车，和用户编号
        System.out.println(orderService.createOrder(cart, 1));
    }
}