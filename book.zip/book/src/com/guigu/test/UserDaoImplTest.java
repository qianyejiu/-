package com.guigu.test;

import com.guigu.dao.UserDao;
import com.guigu.dao.impl.UserDaoImpl;
import com.guigu.pojo.User;
import org.junit.Test;

import static org.junit.Assert.*;

/*
* 生成测试类
* 测试  UserDaoImpl的方法
* */
public class UserDaoImplTest {
    // 创建接口类型，的实现类对象
    UserDao userDao = new UserDaoImpl();

    @Test
    public void queryUserByUsername() {
        if(userDao.queryUserByUsername("张三")==null){
            System.out.println("用户名可用！");
        }else {
            System.out.println("用户名已存在！");
        }
    }

    @Test
    public void queryUserByUsernameAndPassword() {
        if(userDao.queryUserByUsernameAndPassword("admin","admin")==null){
            System.out.println("用户名或密码错误，登录失败！");
        }else {
            System.out.println("登陆成功");
        }
    }

    @Test
    public void saveUser() {
        System.out.println(userDao.saveUser(new User(null,"王五","123","wangwu@qq.com")));
    }
}