package com.guigu.test;

import com.guigu.pojo.Book;
import com.guigu.service.BookService;
import com.guigu.service.impl.BookServiceImpl;
import org.junit.Test;

import java.math.BigDecimal;

import static org.junit.Assert.*;

public class    BookServiceTest {
    BookService bookService = new BookServiceImpl();
    @Test
    public void addBook() {
        int i = bookService.addBook(new Book(null, "业务层测试",
                new BigDecimal(99), "国哥", 100, 100, null));
        System.out.println(i);
    }
    @Test
    public void deleteBookById() {
        bookService.deleteBookById(29);
    }
//    ALTER TABLE t_book AUTO_INCREMENT = 1;   每次删除一行，在增加，会根基前面一行的id自增加
    @Test
    public void updateBook() {
        bookService.updateBook(new Book(2,"国哥业务层",
                new BigDecimal(444),"国哥",100,100,null));
    }
    @Test
    public void queryBookById() {
        System.out.println(bookService.queryBookById(21));
    }
    @Test
    public void queryBooks() {
        for (Book queryBook : bookService.queryBooks()) {
            System.out.println(queryBook);
        }
    }
    @Test
    public void page(){
        System.out.println(bookService.page(2,4));
    }
    @Test
    public void pageByPrice(){
        System.out.println(bookService.pageByPrice(1,4,10,50));
    }
}