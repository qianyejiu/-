package com.guigu.test;

import com.guigu.pojo.User;
import com.guigu.service.UserService;
import com.guigu.service.impl.UserServiceImpl;
import org.junit.Test;
import sun.text.resources.es.FormatData_es_HN;

import static org.junit.Assert.*;

public class UserServiceImplTest {
    //面向接口编程
    UserService userService = new UserServiceImpl();

    @Test
    public void registUser() {
        userService.registUser(new User(null,"bbj","123","bbj@qq.com"));
    }

    @Test
    public void login() {
        System.out.println(userService.login(new User(null,"张三","123", null)));
    }

    @Test
    public void existsUsername() {
        if(userService.existsUsername("张三")){
            System.out.println("用户名已存在");
        }else {
            System.out.println("用户名可用");
        }
    }
}