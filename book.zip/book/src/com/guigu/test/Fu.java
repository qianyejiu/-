package com.guigu.test;

import org.junit.Test;

import java.lang.reflect.Method;

/*
* 调用子类特殊方法
* */
public abstract class Fu  {
    public void method1() {
        System.out.println("父类特方法");
    }
    public abstract void method2();

    @Test
    public void show(){
        try {
            Method method = this.getClass().getDeclaredMethod("method3");
            method.invoke(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
