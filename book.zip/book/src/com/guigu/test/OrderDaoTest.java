package com.guigu.test;

import com.guigu.dao.OrderDao;
import com.guigu.dao.impl.OrderDaoImpl;
import com.guigu.pojo.Order;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.Date;


public class OrderDaoTest {
    @Test
    public void saveOrder() {
        OrderDao orderDao = new OrderDaoImpl();
        //date()---util包的date，userid受t_user的id主键约束，超出了t_user的id出错
        orderDao.saveOrder(new Order("12345",new Date(),new BigDecimal(100),0,1));
    }
}