package com.guigu.test;

public class Zi extends Fu {
    @Override
    public void method2() {

    }

    public void method3(){
        System.out.println("子类特方法");
    }
}
