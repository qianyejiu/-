package com.guigu.test;

import com.guigu.dao.OrderItemDao;
import com.guigu.dao.impl.OrderItemDaoImpl;
import com.guigu.pojo.OrderItem;
import org.junit.Test;

import java.math.BigDecimal;


public class OrderItemDaoTest {
    @Test
    public void saveOrderItem() {
        OrderItemDao orderItemDao = new OrderItemDaoImpl();
        orderItemDao.saveOrderItem(new OrderItem(null,"商品1",1,
                new BigDecimal(100),new BigDecimal(100),"12345"));
    }
}