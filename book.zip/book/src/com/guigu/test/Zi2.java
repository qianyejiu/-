package com.guigu.test;

public class Zi2 extends Fu {
    @Override
    public void method2() {

    }

    public void method3(){
        System.out.println("子类2的特有方法");
    }
}
