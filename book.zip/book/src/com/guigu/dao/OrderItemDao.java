package com.guigu.dao;


import com.guigu.pojo.OrderItem;

// 保存订单项
public interface OrderItemDao {
    public int saveOrderItem(OrderItem orderItem);
}
