package com.guigu.dao;

import com.guigu.pojo.Order;

// 保存订单
public interface OrderDao {
    public  int saveOrder(Order order);
}
