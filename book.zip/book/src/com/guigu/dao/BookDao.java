package com.guigu.dao;

import com.guigu.pojo.Book;

import java.util.List;

public interface BookDao {
    // 增加书籍
    public int addBook(Book book);
    // 通过ID删除书籍
    public int deleteBookById(Integer id);
    // 更新书籍
    public int updateBook(Book book);
    // 根据书籍ID查询
    public Book queryBookById(Integer id);
    // 查询所有书籍，返回集合
    public List<Book> queryBooks();
    // 查询总记录数
    Integer queryForPageTotalCount();
    // 查询某一页
    List<Book> queryForPageItems(int begin, int pageSize);

    Integer queryForPageTotalCountByPrice(int min, int max);

    List<Book> queryForPageItemsByPrice(int begin, int pageSize, int min, int max);
}
