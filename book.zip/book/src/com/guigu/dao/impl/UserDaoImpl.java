package com.guigu.dao.impl;

import com.guigu.dao.UserDao;
import com.guigu.pojo.User;

/*
* Dao层：提供操作数据库的方法
* 实现类：需要实现具体的方法，通过通用的Dao操作实现
* */
public class UserDaoImpl extends BaseDao implements UserDao {
    @Override
    public User queryUserByUsername(String username) {
        String sql = "select id,username,password,email from t_user where username = ?";
        return queryForOne(User.class,sql,username); // 需要查询的条件，通过参数传入
    }

    @Override
    public User queryUserByUsernameAndPassword(String username, String password) {
        String sql = "select `id`,`username`,`password`,`email` from t_user where username = ? and password = ?";
        return queryForOne(User.class,sql,username,password); // 需要查询的条件，通过参数传入
    }

    @Override
    public int saveUser(User user) {
        String sql = "insert into t_user(username,password,email) values(?,?,?)";
        return update(sql,user.getUsername(),user.getPassword(),user.getEmail()); // 需要添加的值，通过User对象传入
    }
}
