package com.guigu.filter;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

public class ManagerFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        // 请求类型转换---能够得到session域
        HttpServletRequest httpServletRequest = (HttpServletRequest) request;
        // 通过session域获取登录用户
        Object user = httpServletRequest.getSession().getAttribute("user");
        // 判断登录与否，进行拦截和放行
        if(user == null){
            // 没有登录，拦截，返回到登录页面
            request.getRequestDispatcher("/pages/user/login.jsp").forward(request,response);
        }else {
            // 有登录，放行
            chain.doFilter(request,response);
        }
    }

    @Override
    public void destroy() {

    }
}
