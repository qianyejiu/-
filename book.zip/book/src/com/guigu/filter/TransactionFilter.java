package com.guigu.filter;

import com.guigu.utils.JdbcUtils;

import javax.servlet.*;
import java.io.IOException;

public class TransactionFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        try {
            chain.doFilter(request,response);
            JdbcUtils.commitAndClose();
        } catch (Exception e) {
            JdbcUtils.rollbackAndClose();  // 异常回滚
            e.printStackTrace();
            throw new RuntimeException(e); // 把异常抛给Tomcat服务器---进行错误页面跳转
        }
    }

    @Override
    public void destroy() {

    }
}
