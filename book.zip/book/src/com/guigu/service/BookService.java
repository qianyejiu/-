package com.guigu.service;

import com.guigu.pojo.Book;
import com.guigu.pojo.Page;

import java.util.List;

public interface BookService {
    // 增加书籍
    public int addBook(Book book);
    // 通过ID删除书籍
    public int deleteBookById(Integer id);
    // 更新书籍
    public int updateBook(Book book);
    // 根据书籍ID查询
    public Book queryBookById(Integer id);
    // 查询所有书籍，返回集合
    public List<Book> queryBooks();

    Page<Book> page(int pageNo, int pageSize);

    Page<Book> pageByPrice(int pageNo, int pageSize, int min, int max);
}
