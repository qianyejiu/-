package com.guigu.service.impl;

import com.guigu.dao.UserDao;
import com.guigu.dao.impl.UserDaoImpl;
import com.guigu.pojo.User;
import com.guigu.service.UserService;

/**
 * service层：提供不同业务 注册、登录、查询用户名可用性
 * 需要操作数据库，--调用Dao----创建Dao实现类对象
 *
 * web-->service-->Dao
 * 所以service层，需要创建Dao对象，使用Dao对象的方法操作数据库
 */
public class UserServiceImpl implements UserService {
    // 需要调用Dao操作数据库
    UserDao userDao = new UserDaoImpl();

    // 注册
    @Override
    public void registUser(User user) {
        userDao.saveUser(user);
    }

    // 登录

    /**
     * 根据对象返回登录结果
     * @param user
     * @return 返回null-登录失败，反之亦然
     */
    @Override
    public User login(User user) {
        return userDao.queryUserByUsernameAndPassword(user.getUsername(),user.getPassword());
    }

    // 查询用户名可用性
    @Override
    public boolean existsUsername(String username) {
        if(userDao.queryUserByUsername(username)==null){
            return false; //没查询到，返回false
        }
        return true; //查询到存在，返回true
    }
}
