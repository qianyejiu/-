package com.guigu.service.impl;

import com.guigu.dao.BookDao;
import com.guigu.dao.OrderDao;
import com.guigu.dao.OrderItemDao;
import com.guigu.dao.impl.BookDaoImpl;
import com.guigu.dao.impl.OrderDaoImpl;
import com.guigu.dao.impl.OrderItemDaoImpl;
import com.guigu.pojo.*;
import com.guigu.service.OrderService;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;

public class OrderServiceImpl implements OrderService {
    // 创建订单、订单项Dao
    private OrderDao orderDao = new OrderDaoImpl();
    private OrderItemDao orderItemDao = new OrderItemDaoImpl();
    private BookDao bookDao = new BookDaoImpl();
    /**
     * 创建订单--- 通过购物车cart、用户userId  1.创建Order订单、2.通过cart获取OrderItem订单项、3.提交订单后修改Book的库存销量
     * 调用多个Dao： orderDao、 orderItemDao、 bookDao
     * Dao之间的代码如果出现异常，会出现事务型异常，导致一部分数据被修改，一部分数据未修改
     *
     * @param cart
     * @param userId
     * @return
     */
    @Override
    public String createOrder(Cart cart, Integer userId) {
        // 订单号==唯一性
        String orderId = System.currentTimeMillis() + "" + userId;
        // 先有订单对象，才有订单项对象
        Order order = new Order(orderId, new Date(), new BigDecimal(100), 0, userId);
        // 保存订单
        orderDao.saveOrder(order);

        // 保存订单后处错
//        int i = 12 / 0;

        // 遍历购物车商品项 --- 存入订单项          ----从购物车中将商品项，取出到订单中，库存、销量变化操作也在该过程中
        for (Map.Entry<Integer, CartItem> entry : cart.getItems().entrySet()) {
            CartItem cartItem = entry.getValue(); // 获取购物车-----商品项
            // 转换为每一个订单项    -----  有了订单order，才能创建订单项，使用orderId
            OrderItem orderItem = new OrderItem(null, cartItem.getName(), cartItem.getCount(),
                    cartItem.getPrice(), cartItem.getTotalPrice(), orderId);
            // 保存订单项到数据库
            orderItemDao.saveOrderItem(orderItem);

            // 通过获取的商品项的id，查询数据库中的数据，返回对应的book Bean对象
            Book book = bookDao.queryBookById(cartItem.getId());
            // 修改book的销量sales和库存stock
            book.setSales(book.getSales() + cartItem.getCount());
            book.setStock(book.getStock() - cartItem.getCount());
            // 通过book，更新数据库中对应的数据
            bookDao.updateBook(book);
        }
        // 清空购物车
        cart.clear();
        // 返回订单号
        return orderId;
    }
}







