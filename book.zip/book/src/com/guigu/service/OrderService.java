package com.guigu.service;

import com.guigu.pojo.Cart;

public interface OrderService {
    // 生成订单
    public String createOrder(Cart cart,Integer userId);
}
